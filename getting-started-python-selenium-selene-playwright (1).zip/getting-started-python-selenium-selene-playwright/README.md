# Getting started with Python for Automated Testing in Browser

This project is an example of a minimal setup in Python to run simplest «search in google» scenario in Web Browser. 

Fore more details (in russian), find a tutorial at the project Wiki: [«Руководство по запуску первого автотеста на Python»](https://github.com/qa-guru/getting-started-python/wiki).